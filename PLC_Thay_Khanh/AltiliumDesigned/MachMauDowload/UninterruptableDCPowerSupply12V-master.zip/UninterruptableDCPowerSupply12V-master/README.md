# UninterruptableDCPowerSupply12V
 DC UPS for a 12V 1A load

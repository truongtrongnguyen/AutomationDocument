# 65wLEDPowerSupply
 48V in 65W LED Powersupply with 12V output for fans

# SolarTracker
 Analog Solar Tracker project
